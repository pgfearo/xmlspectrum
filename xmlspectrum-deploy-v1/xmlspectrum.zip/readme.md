The *app* directory contents
=======
The **_output_** directory contains files created by running XMLSpectrum transforms on files within the **_sample_** directory. The **_xsl_** directory contains the 3 XSLT 2.0 stylesheets that make up this project.

##Links

For usage instructions, see [xmlspectrum/app/xsl/readme](https://github.com/pgfearo/xmlspectrum/blob/master/app/xsl/readme.md)

Introduction and features: [xmlspectrum/readme](https://github.com/pgfearo/xmlspectrum/blob/master/readme.md)








