/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webviewbrowser;

/**
 *
 * @author Philip
 */
public interface FXListener {
    public void callback(String msg);
}
